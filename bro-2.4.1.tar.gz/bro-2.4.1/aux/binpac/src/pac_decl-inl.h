#ifndef pac_decl_inl_h
#define pac_decl_inl_h

#include "pac_id.h"

#endif  // pac_decl_inl_h
