#
# Settings that specify the version of BroControl
#

VERSION = "@VERSION@"
BROBASE = "@PREFIX@"
CFGFILE = "@ETC@/broctl.cfg"
BROSCRIPTDIR = "@BROSCRIPTDIR@"
