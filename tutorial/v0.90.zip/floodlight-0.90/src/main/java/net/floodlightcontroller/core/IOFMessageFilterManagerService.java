package net.floodlightcontroller.core;

import net.floodlightcontroller.core.module.IFloodlightService;

public interface IOFMessageFilterManagerService extends IFloodlightService {
    // empty for now
}
